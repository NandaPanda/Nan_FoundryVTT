/*
function sampleCode () {
	chrome.storage.sync.set(
		{k: v},
		() => {
			// callback
		}
	)
}
*/
